# BradshawVault cinematic intro

Standalone preview asset; not integrated into the application.

- 3840 × 2160, 60 FPS, 4.5 seconds
- H.264 video with AAC audio and fast-start playback
- Rebuilt from the approved red ribbon reveal design at native 4K
- User-supplied intro audio preserved at its original speed
- Ribbon reveal starts at 0.30 s with the first audio hit
- Zoom accelerates into the 2.2 s swell
- Spectral streaks emerge at 2.4 s and decay with the audio
- Ends on black

Run `python render_intro.py` with Pillow, NumPy and FFmpeg installed. Set AUDIO to the supplied MP3 path before rendering.
