from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np, subprocess, math, os
W,H,FPS,DURATION=3840,2160,60,4.5
ROOT=os.path.dirname(os.path.abspath(__file__))
AUDIO=os.path.join(ROOT,'BradshawVault-Intro-Sound.mp3')
OUT=os.path.join(ROOT,'BradshawVault-Cinematic-Intro-4K60.mp4')
font=ImageFont.truetype('/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',290)
text='BradshawVault'; box=font.getbbox(text); tw=box[2]; th=box[3]-box[1]
mask=Image.new('L',(tw+20,th+20));ImageDraw.Draw(mask).text((10,10-box[1]),text,font=font,fill=255)
# Condensed proportions reproduce the approved narrow red wordmark.
mask=mask.resize((int(tw*.88),th+20),Image.Resampling.LANCZOS)
mw,mh=mask.size
rng=np.random.default_rng(5454)
xx=np.arange(mw)[None,:]; yy=np.arange(mh)[:,None]
fibers=(.82+.12*np.sin(xx*.49+yy*.10)+.06*np.sin(xx*1.71+yy*.16))
red=np.zeros((mh,mw,3),dtype=np.uint8);red[:,:,0]=np.clip(235*fibers,0,255);red[:,:,1]=np.clip(9*fibers,0,255);red[:,:,2]=np.clip(20*fibers,0,255)
logo=Image.fromarray(red)
# Vertical spectral filaments retain true black gaps.
lines=[]
colors=[(255,14,35),(255,37,11),(255,94,20),(255,32,88),(228,35,145),(135,37,237),(44,76,255),(17,139,255),(30,215,228)]
for i in range(220):
 x=float(rng.uniform(-.12,1.12)); c=colors[min(8,max(0,int(x*9)))]; lines.append((x,float(rng.uniform(1,9)),c,float(rng.uniform(.35,1)),float(rng.uniform(-.06,.06))))
def ease(x):
 x=max(0,min(1,x));return x*x*(3-2*x)
cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',AUDIO,'-af','apad,afade=t=out:st=3.85:d=0.2','-t',str(DURATION),'-vf','scale=5568:3132:flags=lanczos,crop=3840:2160','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','256k','-movflags','+faststart',OUT]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for frame in range(round(FPS*DURATION)):
 t=frame/FPS; canvas=Image.new('RGB',(W,H))
 if .28<t<3.08:
  # Staggered diagonal ribbon fronts draw the lettering from left to right.
  reveal=np.clip((t-.30)/.85*1.18-(xx/mw)*.92-(1-yy/mh)*.17,0,.075)/.075
  alpha=Image.fromarray((np.asarray(mask)*reveal).astype('uint8'))
  z=1+.025*ease((t-1.12)/.55)
  if t>1.65:z*=math.exp(3.95*ease((t-1.65)/1.33))
  sw,sh=int(mw*z),int(mh*z)
  # Transform only the visible 4K viewport rather than huge intermediate images.
  ox=W/2-sw*.52;oy=H/2-sh*.52
  affine=(1/z,0,-ox/z,0,1/z,-oy/z)
  colored=logo.transform((W,H),Image.Transform.AFFINE,affine,Image.Resampling.BICUBIC)
  am=alpha.transform((W,H),Image.Transform.AFFINE,affine,Image.Resampling.BICUBIC)
  if t>2.60:am=am.point(lambda v:int(v*(1-ease((t-2.60)/.48))))
  canvas.paste(colored,(0,0),am)
 if 2.40<t<4.18:
  env=ease((t-2.4)/.38)*(1-ease((t-3.38)/.8))
  streak=Image.new('RGB',(W,H));d=ImageDraw.Draw(streak)
  spread=1+1.8*ease((t-2.65)/1.5)
  for x,width,c,power,drift in lines:
   xpos=int(W*(.5+(x-.5)*spread+drift*(t-2.4)))
   bright=env*power*(.85+.15*math.sin(t*4+x*13))
   col=tuple(int(v*bright) for v in c)
   d.line((xpos,0,xpos,H),fill=col,width=max(1,int(width)))
  glow=streak.filter(ImageFilter.GaussianBlur(14))
  from PIL import ImageChops
  canvas=ImageChops.add(canvas,ImageChops.add(streak,glow,scale=1.0))
 if frame in (65,100,137,177,210):canvas.resize((960,540)).save(os.path.join(ROOT,f'frame-{frame}.jpg'))
 p.stdin.write(canvas.tobytes())
 if frame%30==0:print(f'{frame}/{round(FPS*DURATION)}',flush=True)
p.stdin.close(); assert p.wait()==0
print(OUT,flush=True)
